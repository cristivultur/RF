package ro.usv.rf;

import java.text.DecimalFormat;
import java.util.Map;

/**
 * 
 * @author fdanci
 *
 */
public class OutputUtil {

	@SuppressWarnings("unchecked")
	public static <K, V> void printMap(Map<K, V> map, int k, double grade) {
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
		System.out.println("K:" + k + "  GRADE: " + grade);

		System.out.print("Nearest neghbour(s): ");
		map.entrySet().stream()
		.forEach(e -> System.out.print(decimalFormat.format(e.getKey()) + ", "));

		System.out.print("\nNearest neghbour(s) class: ");
		map.entrySet().stream()
		.forEach(e -> System.out.print(e.getValue() + ", "));

		String[] gradeClass = new GradeClass((Map<Double, String>) map).getGradeClass();
		System.out.print("\nSearched grade class: " + 
				gradeClass[0] + " (" + gradeClass[1] + " " + gradeClass[0] + ")");

		// NEW LINE
		System.out.println("\n");
	}

}
