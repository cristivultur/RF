package lab4_pack;

public class USVInputFileCustomException extends Exception {

    public USVInputFileCustomException(String message) {
        super(message);
    }

}